﻿using System;
using System.Collections.Generic;
using System.Text;


public class Task
{
    //1.1
    public double fraction(double x)
    {
        return Math.Abs(x - (int)x);
    }

    //1.3
    public int charToNum(char x)
    {
        return x - '0';
    }

    //1.5
    public bool is2Digits(int x)
    {
        return x >= 10 && x <= 99 || x <= -10 && x >= -99;
    }

    //1.7
    public bool isInRange(int a, int b, int num)
    {
        int min = Math.Min(a, b);
        int max = Math.Max(a, b);
        return num >= min && num <= max;
    }

    //1.9
    public bool isEqual(int a, int b, int c)
    {
        return a == b && b == c;
    }



    //2.1
    public int abs(int x)
    {
        if (x < 0)
        {
            return -x;
        }
        return x;
    }

    //2.3
    public bool is35(int x)
    {
        bool div3 = x % 3 == 0;
        bool div5 = x % 5 == 0;
        return div3 != div5;
    }

    //2.5
    public int max3(int x, int y, int z)
    {
        int max = x;
        if (y > max)
        {
            max = y;
        }
        if (z > max)
        {
            max = z;
        }
        return max;
    }

    //2.7
    public int sum2(int x, int y)
    {
        int sum = x + y;
        if (sum >= 10 && sum <= 19)
        {
            return 20;
        }
        return sum;
    }

    //2.9
    public String day(int x)
    {
        switch (x)
        {
            case 1:
                return "Понедельник";
            case 2:
                return "Вторник";
            case 3:
                return "Среда";
            case 4:
                return "Четверг";
            case 5:
                return "Пятница";
            case 6:
                return "Суббота";
            case 7:
                return "Воскресенье";
            default:
                return "Это не день недели";
        }
    }


    //3.1
    public String listNums(int x)
    {
        string result = "";
        if (x >= 0)
        {
            for (int i = 0; i <= x; i++)
            {
                result += i + " ";
            }
        }
        else
        {
            for (int i = x; i <= 0; i++)
            {
                result += i + " ";
            }
        }
        return result;
    }

    //3.3
    public String chet(int x)
    {
        string result = "";
        for (int i = 0; i <= x; i += 2)
        {
            result += i + " ";
        }
        return result;
    }

    //3.5
    public int numLen(long x)
    {
        x = Math.Abs(x);
        if (x == 0)
        {
            return 1;
        }
        int length = 0;
        while (x > 0)
        {
            x /= 10;
            length++;
        }
        return length;
    }

    //3.7
    public void square(int x)
    {
        for (int i = 0; i < x; i++)
        {
            Console.Write("\t");
            for (int j = 0; j < x; j++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
        }
    }

    //3.9
    public void rightTriangle(int x)
    {
        for (int i = 1; i <= x; i++)
        {
            Console.Write("\t");
            for (int j = 0; j < x - i; j++)
            {
                Console.Write(" ");
            }
            for (int j = 0; j < i; j++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
        }
    }

    //4.1
    public int findFirst(int[] arr, int x)
    {
        for (int i = 0; i < arr.Length; i++)
        {
            if (arr[i] == x)
            {
                return i;
            }
        }
        return -1;
    }

    //4.3
    public int maxAbs(int[] arr)
    {
        int max = arr[0];
        for (int i = 1; i < arr.Length; i++)
        {
            if (Math.Abs((long)arr[i]) > Math.Abs((long)max))
            {
                max = arr[i];
            }
        }
        return max;
    }

    //4.5
    public int[] add(int[] arr, int[] ins, int pos)
    {
        int[] result = new int[arr.Length + ins.Length];
        for (int i = 0; i < pos; i++)
        {
            result[i] = arr[i];
        }
        for (int i = 0; i < ins.Length; i++)
        {
            result[pos + i] = ins[i];
        }
        for (int i = pos; i < arr.Length; i++)
        {
            result[ins.Length + i] = arr[i];
        }
        return result;
    }

    //4.7
    public int[] reverseBack(int[] arr)
    {
        int[] result = new int[arr.Length];
        for (int i = 0; i < arr.Length; i++)
        {
            result[i] = arr[arr.Length - 1 - i];
        }
        return result;
    }

    //4.9
    public int[] findAll(int[] arr, int x)
    {
        int count = 0;
        for (int i = 0; i < arr.Length; i++)
        {
            if (arr[i] == x)
            {
                count++;
            }
        }
        int[] result = new int[count];
        int index = 0;
        for (int i = 0; i < arr.Length; i++)
        {
            if (arr[i] == x)
            {
                result[index] = i;
                index++;
            }
        }
        return result;
    }
    public int[] CreateManualArray(int size)
    {
        int[] arr = new int[size];
        for (int i = 0; i < arr.Length; i++)
        {
            Console.Write($"\tВведите элемент [{i}]: ");
            arr[i] = InputValidator.ReadInt();
        }
        return arr;
    }

    public int[] CreateRandomArray(int size, int minValue, int maxValue)
    {
        Random random = new Random();
        int[] arr = new int[size];
        for (int i = 0; i < arr.Length; i++)
        {
            arr[i] = random.Next(minValue, maxValue + 1);
        }
        return arr;
    }
}



