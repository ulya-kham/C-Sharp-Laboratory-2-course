﻿using System;
using System.Collections.Generic;
using System.Text;

public class InputValidator
{
    public static double ReadDouble()
    {
        double value;
        while (!double.TryParse(
            Console.ReadLine()?.Replace('.', ','), out value))
        {
            Console.Write("\tОшибка ввода. Введите вещественное число: ");
        }
        return value;
    }

    public static int ReadInt()
    {
        int value;
        while (!int.TryParse(Console.ReadLine(), out value))
        {
            Console.Write("\tОшибка ввода. Введите целое число: ");
        }
        return value;
    }

    public static char ReadDigit()
    {
        while (true)
        {
            string input = Console.ReadLine();
            if (input.Length == 1 && char.IsDigit(input[0]))
            {
                return input[0];
            }
            Console.Write("\tОшибка ввода. Введите одну цифру от 0 до 9: ");
        }
    }

    public static long ReadLong()
    {
        long value;
        while (!long.TryParse(Console.ReadLine(), out value))
        {
            Console.Write("\tОшибка ввода. Введите целое число: ");
        }
        return value;
    }

    public static int ReadPositiveInt()
    {
        int value;
        while (!int.TryParse(Console.ReadLine(), out value) || value < 0)
        {
            Console.Write("\tОшибка ввода. Введите целое число не меньше нуля: ");
        }
        return value;
    }

    public static int ReadInt(int minValue, int maxValue)
    {
        int value;
        while (!int.TryParse(Console.ReadLine(), out value) || value < minValue || value > maxValue)
        {
            Console.Write($"\tОшибка ввода. Введите число от {minValue} до {maxValue}: ");
        }
        return value;
    }
}

