﻿internal class Program
{
    private static int[] CreateArray(Task task)
    {
        Console.Write("\tВведите количество элементов: ");
        int size = InputValidator.ReadPositiveInt();
        Console.Write("\n\t1 — Ввести массив вручную");
        Console.Write("\n\t2 — Заполнить массив случайно");
        Console.Write("\n\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        if (fillType == 1)
        {
            return task.CreateManualArray(size);
        }
        Console.Write("\n\tВведите минимальное значение: ");
        int minValue = InputValidator.ReadInt();
        Console.Write("\tВведите максимальное значение: ");
        int maxValue = InputValidator.ReadInt();
        while (minValue > maxValue)
        {
            Console.Write("\tОшибка: минимум не может быть больше максимума.\n");
            Console.Write("\tВведите минимальное значение: ");
            minValue = InputValidator.ReadInt();
            Console.Write("\tВведите максимальное значение: ");
            maxValue = InputValidator.ReadInt();
        }
        return task.CreateRandomArray(size, minValue, maxValue);
    }

    private static void PrintArray(int[] arr)
    {
        Console.Write("\t[");
        for (int i = 0; i < arr.Length; i++)
        {
            Console.Write(arr[i]);
            if (i < arr.Length - 1)
            {
                Console.Write(", ");
            }
        }
        Console.WriteLine("]");
    }

    private static void Main(string[] args)
    {
        Task task = new Task();
        while (true)
        {
            Console.Clear();
            Console.WriteLine("\t~~ ЛАБОРАТОРНАЯ РАБОТА №1 ~~ \n");
            Console.WriteLine("\tВыберите задание:\n");
            Console.WriteLine("\t1 — Методы");
            Console.WriteLine("\t2 — Условия");
            Console.WriteLine("\t3 — Циклы");
            Console.WriteLine("\t4 — Массивы");
            Console.WriteLine("\t0 — Выход");
            Console.Write("\n\tВаш выбор: ");
            int taskNumber = InputValidator.ReadInt();
            switch (taskNumber)
            {
                case 1:
                    while (true)
                    {
                        Console.Clear();
                        Console.WriteLine("\tЗАДАНИЕ 1. МЕТОДЫ\n");
                        Console.WriteLine("\t1 — Дробная часть");
                        Console.WriteLine("\t2 — Букву в число");
                        Console.WriteLine("\t3 — Двузначное");
                        Console.WriteLine("\t4 — Диапазон");
                        Console.WriteLine("\t5 — Равенство");
                        Console.WriteLine("\t0 — Назад");
                        Console.Write("\n\tВаш выбор: ");
                        int subtaskNumber = InputValidator.ReadInt();

                        switch (subtaskNumber)
                        {
                            case 1:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 1.1. ДРОБНАЯ ЧАСТЬ\n");
                                Console.Write("\tВведите число: ");
                                double number = InputValidator.ReadDouble();
                                Console.WriteLine($"\n\tОстаток: {task.fraction(number):0.########}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 2:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 1.3. БУКВУ В ЧИСЛО\n");
                                Console.Write("\tВведите цифру от 0 до 9: ");
                                char digit = InputValidator.ReadDigit();
                                int code = digit;
                                Console.WriteLine($"\n\tВведённый символ: {digit}");
                                Console.WriteLine($"\tКод символа: {code}");
                                Console.WriteLine($"\tРезультат преобразования в число: {task.charToNum(digit)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 3:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 1.5. ДВУЗНАЧНОЕ\n");
                                Console.Write("\tВведите целое число: ");
                                int numberForCheck = InputValidator.ReadInt();
                                Console.WriteLine($"\tРезультат: {task.is2Digits(numberForCheck)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 4:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 1.7. ДИАПАЗОН\n");
                                Console.Write("\tВведите первую границу: ");
                                int a = InputValidator.ReadInt();
                                Console.Write("\tВведите вторую границу: ");
                                int b = InputValidator.ReadInt();
                                Console.Write("\tВведите число: ");
                                int num = InputValidator.ReadInt();
                                Console.WriteLine($"\n\tРезультат: {task.isInRange(a, b, num)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 5:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 1.9. РАВЕНСТВО\n");
                                Console.Write("\tВведите первое число: ");
                                int firstNumber = InputValidator.ReadInt();
                                Console.Write("\tВведите второе число: ");
                                int secondNumber = InputValidator.ReadInt();
                                Console.Write("\tВведите третье число: ");
                                int thirdNumber = InputValidator.ReadInt();
                                Console.WriteLine($"\n\tРезультат: {task.isEqual(firstNumber, secondNumber, thirdNumber)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 0:
                                break;

                            default:
                                Console.WriteLine("\tТакого подзадания нет :(\n");
                                Console.Write("\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                        }
                        if (subtaskNumber == 0)
                        {
                            break;
                        }
                    }
                    break;

                case 2:
                    while (true)
                    {
                        Console.Clear();
                        Console.WriteLine("\tЗАДАНИЕ 2. УСЛОВИЯ\n");
                        Console.WriteLine("\t1 — Модуль числа");
                        Console.WriteLine("\t2 — Тридцать пять");
                        Console.WriteLine("\t3 — Тройной максимум");
                        Console.WriteLine("\t4 — Двойная сумма");
                        Console.WriteLine("\t5 — День недели");
                        Console.WriteLine("\t0 — Назад");
                        Console.Write("\n\tВаш выбор: ");
                        int subtaskNumber = InputValidator.ReadInt();
                        switch (subtaskNumber)
                        {
                            case 1:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 2.1. МОДУЛЬ ЧИСЛА\n");
                                Console.Write("\tВведите целое число: ");
                                int number = InputValidator.ReadInt();
                                Console.WriteLine($"\n\tРезультат: {task.abs(number)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 2:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 2.3. ТРИДЦАТЬ ПЯТЬ\n");
                                Console.Write("\tВведите целое число: ");
                                int numberForCheck = InputValidator.ReadInt();
                                Console.WriteLine($"\n\tРезультат: {task.is35(numberForCheck)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 3:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 2.5. ТРОЙНОЙ МАКСИМУМ\n");
                                Console.Write("\tВведите первое число: ");
                                int x = InputValidator.ReadInt();
                                Console.Write("\tВведите второе число: ");
                                int y = InputValidator.ReadInt();
                                Console.Write("\tВведите третье число: ");
                                int z = InputValidator.ReadInt();
                                Console.WriteLine($"\n\tРезультат: {task.max3(x, y, z)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 4:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 2.7. ДВОЙНАЯ СУММА\n");
                                Console.Write("\tВведите первое число: ");
                                int firstNumber = InputValidator.ReadInt();
                                Console.Write("\tВведите второе число: ");
                                int secondNumber = InputValidator.ReadInt();
                                Console.WriteLine($"\n\tРезультат: {task.sum2(firstNumber, secondNumber)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 5:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 2.9. ДЕНЬ НЕДЕЛИ\n");
                                Console.Write("\tВведите номер дня недели от 1 до 7: ");
                                int dayNumber = InputValidator.ReadInt();
                                Console.WriteLine($"\n\tРезультат: {task.day(dayNumber)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 0:
                                break;
                            default:
                                Console.WriteLine("\n\tТакого подзадания нет :(");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                        }
                        if (subtaskNumber == 0)
                        {
                            break;
                        }
                    }
                    break;

                case 3:
                    while (true)
                    {
                        Console.Clear();
                        Console.WriteLine("\tЗАДАНИЕ 3. ЦИКЛЫ\n");
                        Console.WriteLine("\t1 — Числа подряд");
                        Console.WriteLine("\t2 — Четные числа");
                        Console.WriteLine("\t3 — Длина числа");
                        Console.WriteLine("\t4 — Квадрат");
                        Console.WriteLine("\t5 — Правый треугольник");
                        Console.WriteLine("\t0 — Назад");
                        Console.Write("\n\tВаш выбор: ");
                        int subtaskNumber = InputValidator.ReadInt();
                        switch (subtaskNumber)
                        {
                            case 1:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 3.1. ЧИСЛА ПОДРЯД\n");
                                Console.Write("\tВведите число: ");
                                int number = InputValidator.ReadInt();
                                Console.WriteLine($"\n\tРезультат: {task.listNums(number)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 2:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 3.3. ЧЕТНЫЕ ЧИСЛА\n");
                                Console.Write("\tВведите число: ");
                                int numberForCheck = InputValidator.ReadPositiveInt();
                                Console.WriteLine($"\n\tРезультат: {task.chet(numberForCheck)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 3:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 3.5. ДЛИНА ЧИСЛА\n");
                                Console.Write("\tВведите число: ");
                                long numberLength = InputValidator.ReadLong();
                                Console.WriteLine($"\n\tКоличество знаков: {task.numLen(numberLength)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 4:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 3.7. КВАДРАТ\n");
                                Console.Write("\tВведите размер квадрата: ");
                                int squareSize = InputValidator.ReadPositiveInt();
                                Console.WriteLine();
                                task.square(squareSize);
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 5:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 3.9. ПРАВЫЙ ТРЕУГОЛЬНИК\n");
                                Console.Write("\tВведите высоту треугольника: ");
                                int triangleHeight = InputValidator.ReadPositiveInt();
                                Console.WriteLine();
                                task.rightTriangle(triangleHeight);
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 0:
                                break;
                            default:
                                Console.WriteLine("\n\tТакого подзадания нет :(");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                        }
                        if (subtaskNumber == 0)
                        {
                            break;
                        }
                    }
                    break;

                case 4:
                    while (true)
                    {
                        Console.Clear();
                        Console.WriteLine("\tЗАДАНИЕ 4. МАССИВЫ\n");
                        Console.WriteLine("\t1 — Поиск первого значения");
                        Console.WriteLine("\t2 — Поиск максимального");
                        Console.WriteLine("\t3 — Добавление массива в массив");
                        Console.WriteLine("\t4 — Возвратный реверс");
                        Console.WriteLine("\t5 — Все вхождения");
                        Console.WriteLine("\t0 — Назад");
                        Console.Write("\n\tВаш выбор: ");
                        int subtaskNumber = InputValidator.ReadInt();
                        switch (subtaskNumber)
                        {
                            case 1:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 4.1. ПОИСК ПЕРВОГО ЗНАЧЕНИЯ\n");
                                int[] arr = CreateArray(task);
                                Console.WriteLine("\n\tИсходный массив:");
                                PrintArray(arr);
                                Console.Write("\n\tВведите число для поиска: ");
                                int x = InputValidator.ReadInt();
                                Console.WriteLine($"\n\tРезультат: {task.findFirst(arr, x)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 2:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 4.3. ПОИСК МАКСИМАЛЬНОГО\n");
                                int[] maxArray = CreateArray(task);
                                Console.WriteLine("\n\tИсходный массив:");
                                PrintArray(maxArray);
                                Console.WriteLine($"\n\tРезультат: {task.maxAbs(maxArray)}");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 3:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 4.5. ДОБАВЛЕНИЕ МАССИВА В МАССИВ\n");
                                Console.WriteLine("\tПервый массив:");
                                int[] firstArray = CreateArray(task);
                                Console.WriteLine("\n\tВторой массив:");
                                int[] secondArray = CreateArray(task);
                                Console.WriteLine("\n\tИсходные массивы:");
                                PrintArray(firstArray);
                                PrintArray(secondArray);
                                Console.Write($"\n\tВведите позицию вставки от 0 до {firstArray.Length}: ");
                                int position = InputValidator.ReadInt(0, firstArray.Length);
                                int[] addedArray = task.add(firstArray, secondArray, position);
                                Console.WriteLine("\n\tРезультат:");
                                PrintArray(addedArray);
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 4:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 4.7. ВОЗВРАТНЫЙ РЕВЕРС\n");
                                int[] reverseArray = CreateArray(task);
                                Console.WriteLine("\n\tИсходный массив:");
                                PrintArray(reverseArray);
                                int[] reversed = task.reverseBack(reverseArray);
                                Console.WriteLine("\n\tРезультат:");
                                PrintArray(reversed);
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 5:
                                Console.Clear();
                                Console.WriteLine("\tЗАДАНИЕ 4.9. ВСЕ ВХОЖДЕНИЯ\n");
                                int[] findAllArray = CreateArray(task);
                                Console.WriteLine("\n\tИсходный массив:");
                                PrintArray(findAllArray);
                                Console.Write("\n\tВведите число для поиска: ");
                                int searchNumber = InputValidator.ReadInt();
                                int[] indexes = task.findAll(findAllArray, searchNumber);
                                Console.WriteLine("\n\tИндексы вхождений:");
                                PrintArray(indexes);
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                            case 0:
                                break;
                            default:
                                Console.WriteLine("\n\tТакого подзадания нет :(");
                                Console.Write("\n\tНажмите Enter, чтобы продолжить...");
                                Console.ReadLine();
                                break;
                        }
                        if (subtaskNumber == 0)
                        {
                            break;
                        }
                    }
                    break;

                case 0:
                    return;
                default:
                    Console.Clear();
                    Console.WriteLine("\tТакого задания нет :( ");
                    Console.Write("\tНажмите Enter, чтобы продолжить...");
                    Console.ReadLine();
                    break;
            }
        }
    }
}
