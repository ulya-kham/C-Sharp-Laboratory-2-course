﻿using System;
using System.Collections.Generic;

public static class Collections
{
    public static List<int> FillListIntManual(int count)
    {
        List<int> list = new List<int>();
        for (int i = 0; i < count; i++)
        {
            Console.Write($"\tЭлемент {i + 1}: ");
            list.Add(InputValidator.ReadInt());
        }
        return list;
    }

    public static List<int> FillListIntAuto(
        int count, int min, int max)
    {
        List<int> list = new List<int>();
        Random rnd = new Random();
        for (int i = 0; i < count; i++)
        {
            list.Add(rnd.Next(min, max + 1));
        }
        return list;
    }

    public static List<string> FillListStringManual(
        int count)
    {
        List<string> list = new List<string>();
        for (int i = 0; i < count; i++)
        {
            Console.Write($"\tСлово {i + 1}: ");
            list.Add(
                InputValidator.ReadNonEmptyString());
        }
        return list;
    }

    public static List<string> FillListStringAuto(
        int count)
    {
        string[] words = { "Смешарики", "Три кота и одна кошка",
            "Лунтик", "Мойдодыр", "Паравозики Чаггинтон" };
        List<string> list = new List<string>();
        Random rnd = new Random();
        for (int i = 0; i < count; i++)
        {
            list.Add(words[rnd.Next(words.Length)]);
        }
        return list;
    }

    public static int RemoveAllEntries<T>(List<T> list, T item)
    {
        int count = 0;
        int i = list.Count - 1;
        while (i >= 0)
        {
            if (EqualityComparer<T>.Default.Equals(list[i], item))
            {
                list.RemoveAt(i);
                count++;
            }
            i--;
        }
        return count;
    }

    public static void PrintList<T>(List<T> list)
    {
        if (list.Count == 0)
        {
            Console.WriteLine("\t(список пустой)");
            return;
        }
        Console.Write("\t[");
        for (int i = 0; i < list.Count; i++)
        {
            Console.Write(list[i]);
            if (i < list.Count - 1)
            {
                Console.Write(", ");
            }
        }
        Console.WriteLine("]");
    }







    public static LinkedList<int> FillLinkedListIntManual(
        int count)
    {
        LinkedList<int> list = new LinkedList<int>();
        for (int i = 0; i < count; i++)
        {
            Console.Write($"\tЭлемент {i + 1}: ");
            list.AddLast(InputValidator.ReadInt());
        }
        return list;
    }

    public static LinkedList<int> FillLinkedListIntAuto(
        int count, int min, int max)
    {
        LinkedList<int> list = new LinkedList<int>();
        Random rnd = new Random();
        for (int i = 0; i < count; i++)
        {
            list.AddLast(rnd.Next(min, max + 1));
        }
        return list;
    }

    public static LinkedList<string> FillLinkedListStringManual(
        int count)
    {
        LinkedList<string> list = new LinkedList<string>();
        for (int i = 0; i < count; i++)
        {
            Console.Write($"\tЭлемент {i + 1}: ");
            list.AddLast(InputValidator.ReadNonEmptyString());
        }
        return list;
    }

    public static LinkedList<string> FillLinkedListStringAuto(
        int count)
    {
        string[] words = { "компотик", "карамелька", "коржик",
            "угнетенный", "креветыч", "самопризнанный", 
            "послезавтра", "главный", "капризный" };
        LinkedList<string> list = new LinkedList<string>();
        Random rnd = new Random();
        for (int i = 0; i < count; i++)
        {
            list.AddLast(words[rnd.Next(words.Length)]);
        }
        return list;
    }

    public static void PrintLinkedList<T>(
        LinkedList<T> list)
    {
        LinkedListNode<T> node = list.First;
        Console.Write("\t[");
        while (node != null)
        {
            Console.Write(node.Value);
            if (node.Next != null)
            {
                Console.Write(", ");
            }
            node = node.Next;
        }
        Console.WriteLine("]");
    }

    public static void PrintLinkedListReversed<T>(
        LinkedList<T> list)
    {
        LinkedListNode<T> node = list.Last;
        Console.Write("\t[");
        while (node != null)
        {
            Console.Write(node.Value);
            if (node.Previous != null)
            {
                Console.Write(", ");
            }
            node = node.Previous;
        }
        Console.WriteLine("]");
    }



  

    public static void SolveFirmsTask<T>(
        HashSet<T> allItems, HashSet<T>[] sets)
    {
        HashSet<T> common = new HashSet<T>(sets[0]);
        int i = 1;
        while (i < sets.Length)
        {
            common.IntersectWith(sets[i]);
            i++;
        }

        HashSet<T> any = new HashSet<T>();
        i = 0;
        while (i < sets.Length)
        {
            any.UnionWith(sets[i]);
            i++;
        }

        HashSet<T> none = new HashSet<T>(allItems);
        none.ExceptWith(any);

        Console.WriteLine("\n\t1) Закупка каждым заведением:");
        PrintHashSet(common);
        Console.WriteLine("\n\t2) Закупка хотя бы одним:");
        PrintHashSet(any);
        Console.WriteLine("\n\t3) Ни одним заведением:");
        PrintHashSet(none);
    }

    public static void PrintHashSet<T>(HashSet<T> set)
    {
        if (set.Count == 0)
        {
            Console.WriteLine("\t(пусто)");
            return;
        }
        foreach (T item in set)
        {
            Console.WriteLine($"\t- {item}");
        }
    }

    public static bool FillTextFileManual(
        string path, int lines)
    {
        try
        {
            using (StreamWriter writer =
                new StreamWriter(path))
            {
                for (int i = 0; i < lines; i++)
                {
                    Console.Write($"\tСтрока {i + 1}: ");
                    writer.WriteLine(InputValidator.ReadNonEmptyString());
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\tОшибка создания: {ex.Message}");
            return false;
        }
    }

    public static bool FillTextFileAuto(
        string path, int lines)
    {
        string[] words = { "семечки", "кларнет", "писал",
            "ледовое побоище", "главнокомандующий", "перестановка",
            "гномик", "минотавр", "холмики", "шпатлевка" };
        Random rnd = new Random();
        string line = "";
        int wordsCount = 0;
        try
        {
            using (StreamWriter writer =
                new StreamWriter(path))
            {
                for (int i = 0; i < lines; i++)
                {
                    line = "";
                    wordsCount = rnd.Next(3, 7);
                    for (int j = 0; j < wordsCount; j++)
                    {
                        if (j > 0)
                        {
                            line = line + " ";
                        }
                        line = line + words[rnd.Next(words.Length)];
                    }
                    writer.WriteLine(line);
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка создания: {ex.Message}");
            return false;
        }
    }

    public static void PrintTextFile(string path)
    {
        string line = "";
        using (StreamReader reader = new StreamReader(path))
        {
            line = reader.ReadLine();
            while (line != null)
            {
                Console.WriteLine($"\t{line}");
                line = reader.ReadLine();
            }
        }
    }

    public static HashSet<char> CreateVoicedSet()
    {
        string voiced = "бвгджзйлмнр";
        HashSet<char> set = new HashSet<char>();
        for (int i = 0; i < voiced.Length; i++)
        {
            set.Add(voiced[i]);
        }
        return set;
    }

    public static HashSet<char> CollectLettersFromFile(
        string path)
    {
        HashSet<char> letters = new HashSet<char>();
        string line = "";
        char symbol = ' ';
        int i = 0;
        using (StreamReader reader = new StreamReader(path))
        {
            line = reader.ReadLine();
            while (line != null)
            {
                i = 0;
                while (i < line.Length)
                {
                    symbol = char.ToLower(line[i]);
                    if (char.IsLetter(symbol))
                    {
                        letters.Add(symbol);
                    }
                    i++;
                }
                line = reader.ReadLine();
            }
        }
        return letters;
    }

    public static HashSet<T> IntersectSets<T>(
        HashSet<T> first, HashSet<T> second)
    {
        HashSet<T> result = new HashSet<T>(first);
        result.IntersectWith(second);
        return result;
    }

    public static void PrintSetSorted<T>(HashSet<T> set)
    {
        if (set.Count == 0)
        {
            Console.WriteLine("\t(пусто)");
            return;
        }
        List<T> sorted = new List<T>(set);
        sorted.Sort();
        Console.Write("\t");
        for (int i = 0; i < sorted.Count; i++)
        {
            Console.Write(sorted[i] + " ");
        }
        Console.WriteLine();
    }

    public static void SolveVoicedConsonants(string path)
    {
        HashSet<char> voiced = CreateVoicedSet();
        HashSet<char> letters =
            CollectLettersFromFile(path);
        HashSet<char> answer =
            IntersectSets(voiced, letters);
        Console.WriteLine("\n\tЗвонкие согласные в словах:");
        PrintSetSorted(answer);
    }







    private static bool ValidateStudentName(
        string input, out string surname, out string firstName)
    {
        surname = "";
        firstName = "";
        string[] parts = input.Split(' ');
        if (parts.Length != 2)
        {
            return false;
        }
        surname = parts[0];
        firstName = parts[1];
        if (surname.Length == 0 || firstName.Length == 0)
        {
            return false;
        }
        if (surname.Length > 20 || firstName.Length > 15)
        {
            return false;
        }
        int i = 0;
        while (i < surname.Length)
        {
            if (!char.IsLetter(surname[i]))
            {
                return false;
            }
            i++;
        }
        i = 0;
        while (i < firstName.Length)
        {
            if (!char.IsLetter(firstName[i]))
            {
                return false;
            }
            i++;
        }
        return true;
    }


    public static bool FillStudentsFileManual(
        string path, int count)
    {
        string line = "";
        string surname = "";
        string firstName = "";
        bool isValid = false;
        try
        {
            using (StreamWriter writer =
                new StreamWriter(path))
            {
                for (int i = 0; i < count; i++)
                {
                    isValid = false;
                    while (!isValid)
                    {
                        Console.Write(
                            $"\tФамилия и имя {i + 1} " + "(Формат: Фамилия Имя): ");
                        line = InputValidator.ReadNonEmptyString();

                        isValid = ValidateStudentName(
                            line, out surname, out firstName);

                        if (!isValid)
                        {
                            Console.WriteLine(
                                "\n\tОшибка: формат должен быть " +
                                "'Фамилия Имя' (один пробел),");
                            Console.WriteLine(
                                "\n\tФамилия не более 20 символов,");
                            Console.WriteLine(
                                "\n\tИмя не более 15 символов.");
                        }
                    }
                    writer.WriteLine(line);
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\tОшибка создания: {ex.Message}");
            return false;
        }
    }

    public static bool FillStudentsFileAuto(
        string path, int count)
    {
        string[] lastNames = { "Набиуллина", "Жириновский",
            "Собчак", "Навальный", "Макрон", "Ганди",
            "Харрис", "Руденя", "Бабкина", "Кобзон" };
        string[] firstNames = { "Мирослав", "Святополк",
        "Добрыня", "Бронислав", "Горислава", "Матрена",
        "Одария", "Дарьяна", "Пахом", "Пталимей" };
        Random rnd = new Random();
        string line = "";
        try
        {
            using (StreamWriter writer =
                new StreamWriter(path))
            {
                for (int i = 0; i < count; i++)
                {
                    line =
                        lastNames[rnd.Next(lastNames.Length)] +
                        " " +
                        firstNames[rnd.Next(firstNames.Length)];
                    writer.WriteLine(line);
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка создания: {ex.Message}");
            return false;
        }
    }

    public static List<string> ReadStudentsFile(
        string path)
    {
        List<string> students = new List<string>();
        string line = "";
        try
        {
            using (StreamReader reader =
                new StreamReader(path))
            {
                line = reader.ReadLine();
                while (line != null)
                {
                    students.Add(line);
                    line = reader.ReadLine();
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка чтения: {ex.Message}");
        }
        return students;
    }

    public static List<string> GenerateLogins(
        List<string> students)
    {
        Dictionary<string, int> surnameCount =
            new Dictionary<string, int>();
        List<string> logins = new List<string>();
        string surname = "";
        string login = "";
        int count = 0;
        string firstName = "";
        for (int i = 0; i < students.Count; i++)
        {
            if (!ValidateStudentName(
                students[i], out surname, out firstName))
            {
                logins.Add("Ошибка формата");
                continue;
            }

            if (surnameCount.TryGetValue(surname, out count))
            {
                count++;
                surnameCount[surname] = count;
                login = surname + count.ToString();
            }
            else
            {
                surnameCount[surname] = 1;
                login = surname;
            }
            logins.Add(login);
        }
        return logins;
    }

    public static void PrintLogins(
        List<string> students, List<string> logins)
    {
        for (int i = 0; i < logins.Count; i++)
        {
            Console.WriteLine($"\t{students[i]} -> {logins[i]}");
        }
    }
}