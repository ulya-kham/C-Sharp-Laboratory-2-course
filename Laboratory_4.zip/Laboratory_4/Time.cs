﻿using System;

public class Time
{
    private const int MinutesInDay = 1440;
    private const int MinutesInHour = 60;
    private const byte MaxHours = 23;
    private const byte MaxMinutes = 59;

    private byte _hours;
    private byte _minutes;

    public Time()
    {
        _hours = 0;
        _minutes = 0;
    }

    public Time(byte hours, byte minutes)
    {
        if (hours > MaxHours || minutes > MaxMinutes)
        {
            throw new ArgumentOutOfRangeException
                ("Часы 0-23, минуты 0-59");
        }
        _hours = hours;
        _minutes = minutes;
    }

    public Time(Time other)
    {
        if (other == null)
        {
            _hours = 0;
            _minutes = 0;
        }
        else
        {
            _hours = other._hours;
            _minutes = other._minutes;
        }
    }

    public byte Hours
    {
        get { return _hours; }
        set
        {
            if (value > MaxHours)
            {
                throw new ArgumentOutOfRangeException(
                    nameof(value), "Часы должны быть 0-23");
            }
            _hours = value;
        }
    }

    public byte Minutes
    {
        get { return _minutes; }
        set
        {
            if (value > MaxMinutes)
            {
                throw new ArgumentOutOfRangeException(
                    nameof(value), "Минуты должны быть 0-59");
            }
            _minutes = value;
        }
    }


    public Time AddMinutes(uint minutes)
    {
        long total = GetTotalMinutes() + (long)minutes;
        return FromTotalMinutes(total);
    }

    public override string ToString()
    {
        return $"{_hours:D2}:{_minutes:D2}";
    }

    private int GetTotalMinutes()
    {
        return _hours * MinutesInHour + _minutes;
    }

    private static Time FromTotalMinutes(long total)
    {
        total = total % MinutesInDay;
        if (total < 0)
        {
            total = total + MinutesInDay;
        }
        byte hours = (byte)(total / MinutesInHour);
        byte minutes = (byte)(total % MinutesInHour);
        return new Time(hours, minutes);
    }

   


    public static Time operator ++(Time time)
    {
        return FromTotalMinutes(time.GetTotalMinutes() + 1);
    }

    public static Time operator --(Time time)
    {
        return FromTotalMinutes(time.GetTotalMinutes() - 1);
    }

    public static explicit operator byte(Time time)
    {
        return time._hours;
    }

    public static implicit operator bool(Time time)
    {
        return time._hours != 0 || time._minutes != 0;
    }

    public static Time operator +(Time time, uint minutes)
    {
        return FromTotalMinutes(
            time.GetTotalMinutes() + (long)minutes);
    }

    public static Time operator +(uint minutes, Time time)
    {
        return time + minutes;
    }

    public static Time operator -(Time time, uint minutes)
    {
        return FromTotalMinutes(
            time.GetTotalMinutes() - (long)minutes);
    }

    public static Time operator -(uint minutes, Time time)
    {
        return FromTotalMinutes(
            (long)minutes - time.GetTotalMinutes());
    }
}