﻿using System.Collections.Generic;
internal class Program
{
    private static void Main(string[] args)
    {
        int choice = 0;
        bool isRunning = true;
        while (isRunning)
        {
            Console.Clear();
            Console.WriteLine("\t~~ ЛАБОРАТОРНАЯ РАБОТА №4 ~~ \n");
            Console.WriteLine("\tВыберите задание:");
            Console.WriteLine("\t1 - List. Удаление элементов");
            Console.WriteLine("\t2 - LinkedList. Обратный порядок");
            Console.WriteLine("\t3 - HashSet. Закупки техники");
            Console.WriteLine("\t4 - HashSet. Звонкие согласные");
            Console.WriteLine("\t5 - Dictionary. логины");
            Console.WriteLine("\t6 - Перегрузка операций. Добавить минуты");
            Console.WriteLine("\t7 - Перегрузка операций");
            Console.WriteLine("\t0 - Выход");
            Console.Write("\n\tВаш выбор: ");
            choice = InputValidator.ReadInt();
            switch (choice)
            {
                case 1:
                    SolveTask1();
                    break;
                case 2:
                    SolveTask2();
                    break;
                case 3:
                    SolveTask3();
                    break;
                case 4:
                    SolveTask4();
                    break;
                case 5:
                    SolveTask5();
                    break;
                case 6:
                    SolveTask6();
                    break;
                case 7:
                    SolveTask7();
                    break;
                case 0:
                    isRunning = false;
                    break;
                default:
                    Console.WriteLine("\tТакого пункта меню нет");
                    WaitForEnter();
                    break;
            }
        }
    }
    private static void SolveTask1()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 1. LIST ~~\n");
        Console.WriteLine("\tКак вы хотите заполнить список?");
        Console.WriteLine("\t1 - Числами");
        Console.WriteLine("\t2 - Словами");
        Console.Write("\tВаш выбор: ");
        int dataType = InputValidator.ReadInt(1, 2);
        if (dataType == 1)
        {
            RunTask1ForInt();
        }
        else
        {
            RunTask1ForString();
        }
        WaitForEnter();
    }

    private static void RunTask1ForInt()
    {
        Console.WriteLine("\n\t1 - Заполнить вручную");
        Console.WriteLine("\t2 - Заполнить автоматически");
        Console.Write("\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        Console.Write("\n\tСколько элементов в списке? ");
        int count = InputValidator.ReadPositiveInt();
        List<int> list = new List<int>();

        if (fillType == 1)
        {
            list = Collections.FillListIntManual(count);
        }
        else
        {
            Console.Write("\tМинимальное значение: ");
            int min = InputValidator.ReadInt();
            Console.Write("\tМаксимальное значение: ");
            int max = InputValidator.ReadInt();
            while (min > max)
            {
                Console.WriteLine("\tОшибка: минимум > максимума.");
                Console.Write("\tМинимальное значение: ");
                min = InputValidator.ReadInt();
                Console.Write("\tМаксимальное значение: ");
                max = InputValidator.ReadInt();
            }
            list = Collections.FillListIntAuto(count, min, max);
        }

        Console.WriteLine("\n\tИсходный список:");
        Collections.PrintList(list);

        Console.Write("\n\tВведите элемент: ");
        int e = InputValidator.ReadInt();
        int removedCount = Collections.RemoveAllEntries(list, e);
        if (removedCount == 0)
        {
            Console.WriteLine("\n\tТаких элементов в списке нет");
        }
        else
        {
            Console.WriteLine($"\n\tУдалено элементов: {removedCount}");
            Console.WriteLine("\n\tСписок после удаления:");
            Collections.PrintList(list);
        }
    }

    private static void RunTask1ForString()
    {
        Console.WriteLine("\n\t1 - Заполнить вручную");
        Console.WriteLine("\t2 - Заполнить автоматически");
        Console.Write("\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        Console.Write("\n\tСколько элементов в списке? ");
        int count = InputValidator.ReadPositiveInt();
        List<string> list = new List<string>();

        if (fillType == 1)
        {
            list = Collections.FillListStringManual(count);
        }
        else
        {
            list = Collections.FillListStringAuto(count);
        }

        Console.WriteLine("\n\tИсходный список:");
        Collections.PrintList(list);

        Console.Write("\n\tВведите элемент: ");
        string e = InputValidator.ReadNonEmptyString();
        int removedCount = Collections.RemoveAllEntries(list, e);
        if (removedCount == 0)
        {
            Console.WriteLine("\n\tТаких элементов в списке нет");
        }
        else
        {
            Console.WriteLine($"\n\tУдалено элементов: {removedCount}");
            Console.WriteLine("\n\tСписок после удаления:");
            Collections.PrintList(list);
        }
    }
    private static void WaitForEnter()
    {
        Console.Write("\n\tНажмите Enter, чтобы продолжить...");
        Console.ReadLine();
    }

    private static void SolveTask2()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 2. LINKEDLIST ~~\n");
        Console.WriteLine("\tКак заполнить список?");
        Console.WriteLine("\t1 - Числами");
        Console.WriteLine("\t2 - Словами");
        Console.Write("\tВаш выбор: ");
        int dataType = InputValidator.ReadInt(1, 2);
        if (dataType == 1)
        {
            RunTask2ForInt();
        }
        else
        {
            RunTask2ForString();
        }
        WaitForEnter();
    }

    private static void RunTask2ForInt()
    {
        Console.WriteLine("\n\t1 - Заполнить вручную");
        Console.WriteLine("\t2 - Заполнить автоматически");
        Console.Write("\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        Console.Write("\n\tСколько элементов в списке? ");
        int count = InputValidator.ReadPositiveInt();
        LinkedList<int> list = new LinkedList<int>();
        if (fillType == 1)
        {
            list = Collections.FillLinkedListIntManual(count);
        }
        else
        {
            Console.Write("\tМинимальное значение: ");
            int min = InputValidator.ReadInt();
            Console.Write("\tМаксимальное значение: ");
            int max = InputValidator.ReadInt();
            while (min > max)
            {
                Console.WriteLine("\tОшибка: минимум > максимума.");
                Console.Write("\tМинимальное значение: ");
                min = InputValidator.ReadInt();
                Console.Write("\tМаксимальное значение: ");
                max = InputValidator.ReadInt();
            }
            list = Collections.FillLinkedListIntAuto(
                count, min, max);
        }
        if (list.Count == 0)
        {
            Console.WriteLine("\n\tСписок пуст");
            return;
        }
        Console.WriteLine("\n\tИсходный список L:");
        Collections.PrintLinkedList(list);
        Console.WriteLine("\n\tСписок в обратном порядке:");
        Collections.PrintLinkedListReversed(list);
    }

    private static void RunTask2ForString()
    {
        Console.WriteLine("\n\t1 - Заполнить вручную");
        Console.WriteLine("\t2 - Заполнить автоматически");
        Console.Write("\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        Console.Write("\n\tСколько элементов в списке? ");
        int count = InputValidator.ReadPositiveInt();
        LinkedList<string> list = new LinkedList<string>();
        if (fillType == 1)
        {
            list = Collections.FillLinkedListStringManual(count);
        }
        else
        {
            list = Collections.FillLinkedListStringAuto(count);
        }
        if (list.Count == 0)
        {
            Console.WriteLine("\n\tСписок пуст");
            return;
        }
        Console.WriteLine("\n\tИсходный список L:");
        Collections.PrintLinkedList(list);
        Console.WriteLine(
            "\n\tСписок в обратном порядке:");
        Collections.PrintLinkedListReversed(list);
    }
    private static void SolveTask3()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 3. HASHSET ~~\n");
        Console.Write("\tСколько фирм в перечне? ");
        int firmsCount = InputValidator.ReadPositiveInt();
        HashSet<string> allFirms = new HashSet<string>();
        int i = 0;
        string firmName = "";
        while (i < firmsCount)
        {
            Console.Write($"\tНазвание фирмы {i + 1}: ");
            firmName = InputValidator.ReadNonEmptyString();
            while (allFirms.Contains(firmName))
            {
                Console.WriteLine(
                    "\n\tТакая фирма уже есть в списке!");
                Console.Write($"\tНазвание фирмы {i + 1}: ");
                firmName = InputValidator.ReadNonEmptyString();
            }
            allFirms.Add(firmName);
            i++;
        }
        Console.Write("\n\tСколько учебных заведений? ");
        int n = InputValidator.ReadPositiveInt();
        HashSet<string>[] sets = new HashSet<string>[n];
        i = 0;
        int k = 0;
        int j = 0;
        string name = "";

        while (i < n)
        {
            sets[i] = new HashSet<string>();
            Console.WriteLine($"\n\tЗаведение {i + 1}:");
            Console.Write("\n\tУ скольких фирм закупали? ");
            k = InputValidator.ReadInt(0, firmsCount);
            j = 0;

            while (j < k)
            {
                Console.Write($"\tФирма {j + 1}: ");
                name = InputValidator.ReadNonEmptyString();

                while (!allFirms.Contains(name)
                    || sets[i].Contains(name))
                {
                    if (!allFirms.Contains(name))
                    {
                        Console.WriteLine("\n\tТакой фирмы нет в перечне.");
                    }
                    else
                    {
                        Console.WriteLine("\n\tЭта фирма уже указана.");
                    }

                    Console.Write($"\tФирма {j + 1}: ");
                    name = InputValidator.ReadNonEmptyString();
                }

                sets[i].Add(name);
                j++;
            }

            i++;
        }

        Collections.SolveFirmsTask(allFirms, sets);
        WaitForEnter();
    }



    private static void SolveTask4()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 4. HASHSET ~~\n");
        string path = "task4.txt";
        Console.WriteLine("\t1 - Заполнить вручную");
        Console.WriteLine("\t2 - Заполнить автоматически");
        Console.Write("\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        Console.Write("\n\tСколько строк? ");
        int lines = InputValidator.ReadPositiveInt();
        bool isSuccess = false;
        if (fillType == 1)
        {
            isSuccess = Collections.FillTextFileManual(path, lines);
        }
        else
        {
            isSuccess = Collections.FillTextFileAuto(path, lines);
        }
        if (!isSuccess)
        {
            Console.WriteLine("\n\tНе удалось создать файл.");
            return;
        }
        Console.WriteLine("\n\tСодержимое файла:");
        Collections.PrintTextFile(path);
        Collections.SolveVoicedConsonants(path);
        WaitForEnter();
    }

    private static void SolveTask5()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 5. DICTIONARY ~~\n");
        string path = "task5.txt";
        Console.WriteLine("\t1 - Заполнить вручную");
        Console.WriteLine("\t2 - Заполнить автоматически");
        Console.Write("\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        Console.Write("\n\tКоличество учеников (меньше 100): ");
        int count = InputValidator.ReadInt(1, 100);

        bool isSuccess = false;
        if (fillType == 1)
        {
            isSuccess = Collections.FillStudentsFileManual(path, count);
        }
        else
        {
            isSuccess = Collections.FillStudentsFileAuto(path, count);
        }

        if (!isSuccess)
        {
            Console.WriteLine("\n\tНе удалось создать файл.");
            return;
        }

        Console.WriteLine("\n\tСодержимое файла:");
        List<string> students = Collections.ReadStudentsFile(path);
        for (int i = 0; i < students.Count; i++)
        {
            Console.WriteLine($"\t{students[i]}");
        }

        Console.WriteLine("\n\tСформированные логины:");
        List<string> logins = Collections.GenerateLogins(students);
        Collections.PrintLogins(students, logins);
        WaitForEnter();
    }


    private static void SolveTask6()
    {
        Console.Clear();
        Console.WriteLine( "\t~~ ЗАДАНИЕ 6. КЛАСС TIME ~~\n");
        Time defaultTime = new Time();
        Console.WriteLine("\tКонструктор по умолчанию:");
        Console.WriteLine($"\t{defaultTime}");
        Console.Write("\n\tВведите часы (0-23): ");
        byte hours = (byte)InputValidator.ReadInt(0, 23);
        Console.Write("\tВведите минуты (0-59): ");
        byte minutes = (byte)InputValidator.ReadInt(0, 59);
        Time time = new Time(hours, minutes);
        Console.WriteLine("\n\tКонструктор с параметрами:");
        Console.WriteLine($"\t{time}");
        Time copy = new Time(time);
        Console.WriteLine("\n\tКонструктор копирования:");
        Console.WriteLine($"\t{copy}");

        Console.WriteLine("\n\tПроверка свойств:");
        Console.WriteLine($"\tHours = {time.Hours}");
        Console.WriteLine($"\tMinutes = {time.Minutes}");

        Console.Write("\n\tНовые часы (0-23): ");
        time.Hours = (byte)InputValidator.ReadInt(0, 23);

        Console.Write("\tНовые минуты (0-59): ");
        time.Minutes = (byte)InputValidator.ReadInt(0, 59);

        Console.WriteLine($"\n\tИзмененное время: {time}");
        Console.WriteLine($"\tКопия времени: {copy}");

        Console.Write("\n\tСколько минут добавить? ");
        uint add = InputValidator.ReadUInt();
        Time result = time.AddMinutes(add);
        Console.WriteLine($"\t{time} + {add} мин = {result}");
        WaitForEnter();
    }

    private static void SolveTask7()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 7. ОПЕРАТОРЫ TIME ~~\n");
        Console.Write("\tВведите часы (0-23): ");
        byte hours = (byte)InputValidator.ReadInt(0, 23);
        Console.Write("\tВведите минуты (0-59): ");
        byte minutes = (byte)InputValidator.ReadInt(0, 59);
        Time time = new Time(hours, minutes);
        Console.WriteLine($"\n\tИсходное время: {time}");
        time++;
        Console.WriteLine($"\n\tПосле time++: {time}");
        time--;
        Console.WriteLine($"\tПосле time--: {time}");
        Console.WriteLine("\n\tПроверка перехода через полночь:");

        Time lastMinute = new Time(23, 59);
        Console.WriteLine($"\tДо ++: {lastMinute}");
        lastMinute++;
        Console.WriteLine($"\tПосле ++: {lastMinute}");

        Time firstMinute = new Time(0, 0);
        Console.WriteLine($"\tДо --: {firstMinute}");
        firstMinute--;
        Console.WriteLine( $"\tПосле --: {firstMinute}");
        Console.Write("\n\tМинуты для + и -: ");
        uint value = InputValidator.ReadUInt();
        Time sumRight = time + value;
        Time sumLeft = value + time;
        Time diffRight = time - value;

        Console.WriteLine($"\t{time} + {value} = {sumRight}");
        Console.WriteLine($"\t{value} + {time} = {sumLeft}");
        Console.WriteLine($"\t{time} - {value} = {diffRight}");

        try
        {
            Time diffLeft = value - time;
            Console.WriteLine($"\t{value} - {time} = {diffLeft}");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"\t{value} - {time} = Ошибка: {ex.Message}");
        }

        byte timeHours = (byte)time;
        Console.WriteLine($"\n\t(byte){time} = {timeHours}");

        bool isNonZero = time;
        Console.WriteLine($"\n\t(bool){time} = {isNonZero}");

        WaitForEnter();
 
    }
}