﻿using System;
using System.IO;
using static Files;
internal class Program
{
    private static void Main(string[] args)
    {
        int choice = 0;
        bool isRunning = true;
        while (isRunning)
        {
            Console.Clear();
            Console.WriteLine("\t~~ ЛАБОРАТОРНАЯ РАБОТА №3 ~~ \n");
            Console.WriteLine("\tВыберите задание:");
            Console.WriteLine("\t1 - Заполнение двумерных массивов");
            Console.WriteLine("\t2 - Максимальный из неповторяющихся");
            Console.WriteLine("\t3 - Вычисление по формуле");
            Console.WriteLine("\t4 - Бинарные файлы. Четные");
            Console.WriteLine("\t5 - Бинарные файлы и структуры. Багаж");
            Console.WriteLine("\t6 - Текстовые файлы. Разность половин");
            Console.WriteLine("\t7 - Текстовый файл. Сумма элементов");
            Console.WriteLine("\t8 - Текстовый файл. Короткая и длинная строка");
            Console.WriteLine("\t0 - Выход");
            Console.Write("\n\tВаш выбор: ");
            choice = InputValidator.ReadInt();
            switch (choice)
            {
                case 1:
                    SolveTask1();
                    break;
                case 2:
                    SolveTask2();
                    break;
                case 3:
                    SolveTask3();
                    break;
                case 4:
                    SolveTask4();
                    break;
                case 5:
                    SolveTask5();
                    break;
                case 6:
                    SolveTask6();
                    break;
                case 7:
                    SolveTask7();
                    break;
                case 8:
                    SolveTask8();
                    break;
                case 0:
                    isRunning = false;
                    break;
                default:
                    Console.WriteLine(
                        "\tТакого пункта меню нет");
                    WaitForEnter();
                    break;
            }
        }
    }

    private static void SolveTask1()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 1. " +
            "ЗАПОЛНЕНИЕ ДВУМЕРНЫХ МАССИВОВ ~~\n");
        Console.WriteLine("\tМассив 1 ");
        Console.Write("\tВведите n - строк, массива 1: ");
        int rows = InputValidator.ReadPositiveInt();
        Console.Write("\tВведите m - столбцов, массива 1: ");
        int cols = InputValidator.ReadPositiveInt();
        Console.WriteLine("\tЗаполнение по строкам справа - налево:");
        Matrix matrix1 = new Matrix(rows, cols);
        Console.WriteLine(matrix1);
        Console.WriteLine("\n\tМассив 2 ");
        Console.Write("\tВведите n - строк/столбцов, массива 2: ");
        int n = InputValidator.ReadPositiveInt();
        Console.WriteLine("\tСлучайные значения:\n");
        Matrix matrix2 = new Matrix(n, -17, 36, 100, 10000);
        Console.WriteLine(matrix2);
        Console.WriteLine("\n\tМассив 3 ");
        Console.WriteLine("\tРазмерность как у массива 2," +
            " автоматическое заполенние\n");
        Matrix matrix3 = new Matrix(n);
        Console.WriteLine(matrix3);
        WaitForEnter();
    }

    private static void SolveTask2()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 2. " +
            "МАКСИМАЛЬНЫЙ ИЗ НЕПОВТОРЯЮЩИХСЯ ~~\n");
        Console.WriteLine("\t1 - Заполнить вручную");
        Console.WriteLine("\t2 - Заполнить автоматически");
        Console.Write("\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        Matrix matrix = new Matrix();
        if (fillType == 1)
        {
            Console.Write("\tВведите количество строк: ");
            int rows = InputValidator.ReadPositiveInt();
            Console.Write(
                "\tВведите количество столбцов: ");
            int cols = InputValidator.ReadPositiveInt();
            matrix.FillManual(rows, cols);
        }
        else
        {
            Console.Write("\tВведите количество строк: ");
            int rows = InputValidator.ReadPositiveInt();
            Console.Write(
                "\tВведите количество столбцов: ");
            int cols = InputValidator.ReadPositiveInt();
            Console.Write("\tМинимальное значение: ");
            int min = InputValidator.ReadInt();
            Console.Write("\tМаксимальное значение: ");
            int max = InputValidator.ReadInt();
            while (min > max)
            {
                Console.WriteLine(
                    "\tОшибка: минимум больше максимума.");
                Console.Write("\tМинимальное значение: ");
                min = InputValidator.ReadInt();
                Console.Write("\tМаксимальное значение: ");
                max = InputValidator.ReadInt();
            }
            matrix.FillRandom(rows, cols, min, max);
        }
        Console.WriteLine("\n\tМатрица:");
        Console.WriteLine(matrix);
        int? result = matrix.MaxUnique();
        if (result == null)
        {
            Console.WriteLine(
                "\n\tНеповторяющихся элементов нет");
        }
        else
        {
            Console.WriteLine(
                $"\n\tМаксимальный неповторяющийся: {result}");
        }
        WaitForEnter();
    }

    private static void SolveTask3()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 3. " +
            "ВЫЧИСЛЕНИЕ ПО ФОРМУЛЕ ~~\n");
        Console.WriteLine("\tФормула: 2*A - 3*B*C");
        Console.Write("\tВведите количество строк " +
            "(для A и B): ");
        int n = InputValidator.ReadPositiveInt();
        Console.Write("\tВведите количество столбцов " +
            "(для A и C): ");
        int m = InputValidator.ReadPositiveInt();
        Console.Write("\tВведите количество " +
            "столбцов для B и строк для C: ");
        int k = InputValidator.ReadPositiveInt();
        Matrix a = new Matrix();
        Matrix b = new Matrix();
        Matrix c = new Matrix();
        FillMatrix(a, "A", n, m);
        FillMatrix(b, "B", n, k);
        FillMatrix(c, "C", k, m);
        Console.WriteLine("\n\tМатрица A:");
        Console.WriteLine(a);
        Console.WriteLine("\n\tМатрица B:");
        Console.WriteLine(b);
        Console.WriteLine("\n\tМатрица C:");
        Console.WriteLine(c);
        try
        {
            Console.WriteLine("\n\t1)  B*C:");
            Console.WriteLine(b * c);
            Console.WriteLine("\n\t2)  3*B*C:");
            Console.WriteLine(3 * b * c);
            Console.WriteLine("\n\t3)  2*A:");
            Console.WriteLine(2 * a);
            Matrix result = 2 * a - 3 * b * c;
            Console.WriteLine(
                "\n\tРезультат: 2*A - 3*B*C:");
            Console.WriteLine(result);
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"\n\tОшибка: {ex.Message}");
        }
        WaitForEnter();
    }

    private static void SolveTask4()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 4. " +
            "БИНАРНЫЕ ФАЙЛЫ. ЧЕТНЫЕ ~~\n");
        string inputPath = "input.bin";
        string outputPath = "output.bin";
        Console.WriteLine("\t1 - Заполнить вручную");
        Console.WriteLine("\t2 - Заполнить случайно");
        Console.Write("\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        Console.Write("\tСколько чисел записать? ");
        int count = InputValidator.ReadPositiveInt();

        bool isSuccess = false;
        if (fillType == 1)
        {
            isSuccess = Files.FillBinaryFileManual(
                inputPath, count);
        }
        else
        {
            Console.Write("\tМинимальное значение: ");
            int min = InputValidator.ReadInt();
            Console.Write("\tМаксимальное значение: ");
            int max = InputValidator.ReadInt();
            while (min > max)
            {
                Console.WriteLine(
                    "\tОшибка: минимум > максимума.");
                Console.Write("\tМинимальное значение: ");
                min = InputValidator.ReadInt();
                Console.Write("\tМаксимальное значение: ");
                max = InputValidator.ReadInt();
            }
            isSuccess = Files.FillBinaryFileAuto(
                inputPath, count, min, max);
        }

        if (!isSuccess)
        {
            Console.WriteLine(
                "\tНе удалось создать файл. Операция прервана.");
            WaitForEnter();
            return;
        }

        Console.WriteLine("\n\tИсходный файл:");
        PrintArray(Files.ReadBinaryFile(inputPath));
        int evenCount = Files.FilterEvenBinary(
            inputPath, outputPath);
        Console.WriteLine($"\n\tЧётных чисел: {evenCount}");
        Console.WriteLine($"\tРезультат в {outputPath}:");
        int[] result = Files.ReadBinaryFile(outputPath);
        if (result.Length == 0)
        {
            Console.WriteLine("\tЧётных чисел нет");
        }
        else
        {
            PrintArray(result);
        }
        WaitForEnter();
    }

    private static void SolveTask5()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 5. " +
            "БИНАРНЫЕ ФАЙЛЫ И СТРУКТУРЫ. БАГАЖ~~\n");
        string path = "luggage.xml";
        Console.WriteLine("\t1 - Заполнить вручную");
        Console.WriteLine("\t2 - Заполнить автоматически");
        Console.Write("\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        Console.Write("\tКоличество пассажиров: ");
        int passengers = InputValidator.ReadPositiveInt();

        bool isSuccess = false;
        if (fillType == 1)
        {
            isSuccess = Files.FillLuggageFileManual(
                path, passengers);
        }
        else
        {
            isSuccess = Files.FillLuggageFileAuto(
                path, passengers);
        }

        if (!isSuccess)
        {
            Console.WriteLine(
                "\tНе удалось создать файл. Операция прервана.");
            WaitForEnter();
            return;
        }

        Console.WriteLine("\n\tСодержимое файла:");
        PassengerLuggage[] data = Files.ReadLuggageFile(path);
        Files.PrintLuggage(data);

        double m = 0;
        while (m <= 0)
        {
            Console.Write("\n\tВведите m (кг): ");
            m = InputValidator.ReadDouble();
            if (m <= 0)
            {
                Console.WriteLine(
                    "\tОшибка: m должно быть > 0.");
            }
        }
        Console.WriteLine("\n\tРешение:");
        Files.FindLuggageByAverage(path, m);
        WaitForEnter();
    }

    private static void SolveTask6()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 6. " +
            "ТЕКСТОВЫЕ ФАЙЛЫ. РАЗНОСТЬ ПОЛОВИН ~~\n");
        string path = "task6.txt";
        Console.WriteLine("\t1 - Заполнить вручную");
        Console.WriteLine("\t2 - Заполнить случайно");
        Console.Write("\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        Console.Write("\tСколько чисел записать? ");
        int count = InputValidator.ReadPositiveInt();
        while (count % 2 != 0)
        {
            Console.WriteLine(
                "\tОшибка: количество должно быть чётным.");
            Console.Write("\tСколько чисел записать? ");
            count = InputValidator.ReadPositiveInt();
        }

        bool isSuccess = false;
        if (fillType == 1)
        {
            isSuccess = Files.FillTextFileManual(path, count);
        }
        else
        {
            Console.Write("\tМинимальное значение: ");
            int min = InputValidator.ReadInt();
            Console.Write("\tМаксимальное значение: ");
            int max = InputValidator.ReadInt();
            while (min > max)
            {
                Console.WriteLine(
                    "\tОшибка: минимум > максимума.");
                Console.Write("\tМинимальное значение: ");
                min = InputValidator.ReadInt();
                Console.Write("\tМаксимальное значение: ");
                max = InputValidator.ReadInt();
            }
            isSuccess = Files.FillTextFileAuto(
                path, count, min, max);
        }

        if (!isSuccess)
        {
            Console.WriteLine(
                "\tНе удалось создать файл. Операция прервана.");
            WaitForEnter();
            return;
        }

        Console.WriteLine("\n\tСодержимое файла:");
        PrintArray(Files.ReadTextFileNumbers(path));
        Console.WriteLine("\n\tРешение:");
        Files.DiffOfHalves(path);
        WaitForEnter();
    }

    private static void SolveTask7()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 7. " +
            "ТЕКСТОВЫЙ ФАЙЛ. СУММА ЭЛЕМЕНТОВ ~~\n");
        string path = "task7.txt";
        Console.WriteLine("\t1 - Заполнить вручную");
        Console.WriteLine("\t2 - Заполнить случайно");
        Console.Write("\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        Console.Write("\tСколько строк? ");
        int lines = InputValidator.ReadPositiveInt();
        Console.Write("\tСколько чисел в строке? ");
        int perLine = InputValidator.ReadPositiveInt();

        bool isSuccess = false;
        if (fillType == 1)
        {
            isSuccess = Files.FillTextFileSeveralManual(
                path, lines, perLine);
        }
        else
        {
            Console.Write("\tМинимальное значение: ");
            int min = InputValidator.ReadInt();
            Console.Write("\tМаксимальное значение: ");
            int max = InputValidator.ReadInt();
            while (min > max)
            {
                Console.WriteLine(
                    "\tОшибка: минимум > максимума.");
                Console.Write("\tМинимальное значение: ");
                min = InputValidator.ReadInt();
                Console.Write("\tМаксимальное значение: ");
                max = InputValidator.ReadInt();
            }
            isSuccess = Files.FillTextFileSeveralAuto(
                path, lines, perLine, min, max);
        }

        if (!isSuccess)
        {
            Console.WriteLine(
                "\tНе удалось создать файл. Операция прервана.");
            WaitForEnter();
            return;
        }

        Console.WriteLine("\n\tСодержимое файла:");
        Files.PrintTextFile(path);
        Console.WriteLine("\n\tРешение:");
        Console.WriteLine(
            $"\tСумма элементов: {Files.SumElements(path)}");
        WaitForEnter();
    }

    private static void SolveTask8()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 8. " +
            "ТЕКСТОВЫЙ ФАЙЛ. КОРОТКАЯ И ДЛИННАЯ СТРОКА ~~\n");
        string inputPath = "task8_in.txt";
        string outputPath = "task8_out.txt";
        Console.WriteLine("\t1 - Заполнить вручную");
        Console.WriteLine("\t2 - Заполнить автоматически");
        Console.Write("\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        Console.Write("\tСколько строк? ");
        int count = InputValidator.ReadPositiveInt();

        bool isSuccess = false;
        if (fillType == 1)
        {
            isSuccess = Files.FillTextFileByLines(
                inputPath, count);
        }
        else
        {
            isSuccess = Files.FillTextFileByWords(
                inputPath, count);
        }

        if (!isSuccess)
        {
            Console.WriteLine(
                "\tНе удалось создать файл. Операция прервана.");
            WaitForEnter();
            return;
        }

        Console.WriteLine("\n\tСодержимое файла:");
        Files.PrintTextFile(inputPath);
        Console.WriteLine("\n\tРешение:");
        Files.CopyShortestAndLongest(inputPath, outputPath);
        Console.WriteLine($"\n\tФайл {outputPath}:");
        Files.PrintTextFile(outputPath);
        WaitForEnter();
    }

    private static void FillMatrix(
        Matrix matrix, string name, int rows, int cols)
    {
        Console.WriteLine(
            $"\n\tМатрица {name} ({rows}x{cols}):");
        Console.WriteLine("\t1 - Заполнить вручную");
        Console.WriteLine("\t2 - Заполнить автоматически");
        Console.Write("\tВаш выбор: ");
        int fillType = InputValidator.ReadInt(1, 2);
        if (fillType == 1)
        {
            matrix.FillManual(rows, cols);
        }
        else
        {
            Console.Write("\tМинимальное значение: ");
            int min = InputValidator.ReadInt();
            Console.Write("\tМаксимальное значение: ");
            int max = InputValidator.ReadInt();
            while (min > max)
            {
                Console.WriteLine(
                    "\tОшибка: минимум больше максимума.");
                Console.Write("\tМинимальное значение: ");
                min = InputValidator.ReadInt();
                Console.Write("\tМаксимальное значение: ");
                max = InputValidator.ReadInt();
            }
            matrix.FillRandom(rows, cols, min, max);
        }
    }
    private static void PrintArray(int[] arr)
    {
        Console.Write("\t[");
        for (int i = 0; i < arr.Length; i++)
        {
            Console.Write(arr[i]);
            if (i < arr.Length - 1)
            {
                Console.Write(", ");
            }
        }
        Console.WriteLine("]");
    }
    private static void WaitForEnter()
    {
        Console.Write(
            "\n\tНажмите Enter, чтобы продолжить...");
        Console.ReadLine();
    }
}