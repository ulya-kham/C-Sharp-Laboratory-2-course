﻿using System;
using System.IO;
using System.Xml.Serialization;

public static class Files
{
    public static bool FillBinaryFileAuto(
        string path, int count, int min, int max)
    {
        Random rnd = new Random();
        try
        {
            using (BinaryWriter writer = new BinaryWriter(
                File.Open(path, FileMode.Create)))
            {
                for (int i = 0; i < count; i++)
                {
                    writer.Write(rnd.Next(min, max + 1));
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка создания: {ex.Message}");
            return false;
        }
    }

    public static bool FillBinaryFileManual(
        string path, int count)
    {
        try
        {
            using (BinaryWriter writer = new BinaryWriter(
                File.Open(path, FileMode.Create)))
            {
                for (int i = 0; i < count; i++)
                {
                    Console.Write($"\tЧисло {i + 1}: ");
                    int num = InputValidator.ReadInt();
                    writer.Write(num);
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка создания: {ex.Message}");
            return false;
        }
    }

    
    public static int[] ReadBinaryFile(string path)
    {
        if (!File.Exists(path))
        {
            return new int[0];
        }
        try
        {
            using (BinaryReader reader = new BinaryReader(
                File.Open(path, FileMode.Open)))
            {
                int count = (int)(reader.BaseStream.Length / 4);
                int[] result = new int[count];
                for (int i = 0; i < count; i++)
                {
                    result[i] = reader.ReadInt32();
                }
                return result;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка чтения: {ex.Message}");
            return new int[0];
        }
    }

    public static int FilterEvenBinary(
        string inputPath, string outputPath)
    {
        int count = 0;
        try
        {
            using (BinaryReader reader = new BinaryReader(
                File.Open(inputPath, FileMode.Open)))
            using (BinaryWriter writer = new BinaryWriter(
                File.Open(outputPath, FileMode.Create)))
            {
                while (reader.BaseStream.Position
                    < reader.BaseStream.Length)
                {
                    int num = reader.ReadInt32();
                    if (num % 2 == 0)
                    {
                        writer.Write(num);
                        count++;
                    }
                }
            }
        }
        catch (IOException ex)
        {
            Console.WriteLine(
                $"\tОшибка файла: {ex.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка: {ex.Message}");
        }
        return count;
    }


    public struct LuggageItem
    {
        [XmlElement]
        public string Name;
        [XmlElement]
        public double Weight;
    }

    public struct PassengerLuggage
    {
        [XmlElement]
        public string PassengerName;
        [XmlArray]
        [XmlArrayItem]
        public LuggageItem[] Items;
    }

    public static bool FillLuggageFileAuto(
        string path, int passengers)
    {
        string[] names = { "чемодан", "сумка",
            "коробка", "рюкзак", "пакет", "авоська", "маечка", "шоппер" };
        Random rnd = new Random();
        PassengerLuggage[] data =
            new PassengerLuggage[passengers];
        for (int i = 0; i < passengers; i++)
        {
            data[i].PassengerName = "Пассажир " + (i + 1);
            int items = rnd.Next(1, 5);
            data[i].Items = new LuggageItem[items];
            for (int j = 0; j < items; j++)
            {
                data[i].Items[j].Name =
                    names[rnd.Next(names.Length)];
                data[i].Items[j].Weight =
                    Math.Round(rnd.NextDouble() * 24 + 1, 1);
            }
        }
        return SaveLuggage(path, data);
    }

    public static bool FillLuggageFileManual(
        string path, int passengers)
    {
        PassengerLuggage[] data =
            new PassengerLuggage[passengers];
        for (int i = 0; i < passengers; i++)
        {
            Console.Write($"\tИмя пассажира {i + 1}: ");
            data[i].PassengerName =
                InputValidator.ReadNonEmptyString();
            Console.Write("\tКоличество единиц багажа: ");
            int items = InputValidator.ReadPositiveInt();
            data[i].Items = new LuggageItem[items];
            for (int j = 0; j < items; j++)
            {
                Console.Write($"\tНазвание {j + 1}: ");
                data[i].Items[j].Name =
                    InputValidator.ReadNonEmptyString();
                double weight = 0;
                while (weight <= 0)
                {
                    Console.Write("\tЕё масса (кг): ");
                    weight = InputValidator.ReadDouble();
                    if (weight <= 0)
                    {
                        Console.WriteLine(
                            "\tОшибка: масса должна быть > 0.");
                    }
                }
                data[i].Items[j].Weight = weight;
            }
        }
        return SaveLuggage(path, data);
    }

    private static bool SaveLuggage(
        string path, PassengerLuggage[] data)
    {
        try
        {
            XmlSerializer serializer =
                new XmlSerializer(typeof(PassengerLuggage[]));
            using (StreamWriter writer =
                new StreamWriter(path))
            {
                serializer.Serialize(writer, data);
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка создания: {ex.Message}");
            return false;
        }
    }

    public static PassengerLuggage[] ReadLuggageFile(
        string path)
    {
        if (!File.Exists(path))
        {
            Console.WriteLine("\tФайл не найден");
            return new PassengerLuggage[0];
        }
        try
        {
            XmlSerializer serializer =
                new XmlSerializer(typeof(PassengerLuggage[]));
            using (StreamReader reader =
                new StreamReader(path))
            {
                return (PassengerLuggage[])
                    serializer.Deserialize(reader);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tФайл повреждён: {ex.Message}");
            return new PassengerLuggage[0];
        }
    }

    public static void PrintLuggage(
        PassengerLuggage[] data)
    {
        for (int i = 0; i < data.Length; i++)
        {
            Console.WriteLine($"\t{data[i].PassengerName}:");
            for (int j = 0; j < data[i].Items.Length; j++)
            {
                Console.WriteLine(
                    $"\t\t{data[i].Items[j].Name} - " +
                    $"{data[i].Items[j].Weight} кг");
            }
        }
    }

    public static void FindLuggageByAverage(
        string path, double m)
    {
        PassengerLuggage[] data = ReadLuggageFile(path);
        double totalWeight = 0;
        int totalCount = 0;
        for (int i = 0; i < data.Length; i++)
        {
            for (int j = 0; j < data[i].Items.Length; j++)
            {
                totalWeight = totalWeight +
                    data[i].Items[j].Weight;
                totalCount++;
            }
        }
        if (totalCount == 0)
        {
            Console.WriteLine("\tФайл пуст");
            return;
        }
        double globalAvg = totalWeight / totalCount;
        Console.WriteLine(
            $"\tОбщая средняя масса: " +
            $"{Math.Round(globalAvg, 2)} кг");
        Console.WriteLine($"\tДопуск m = {m} кг\n");
        bool found = false;
        for (int i = 0; i < data.Length; i++)
        {
            double weight = 0;
            int count = data[i].Items.Length;
            for (int j = 0; j < count; j++)
            {
                weight = weight + data[i].Items[j].Weight;
            }
            double avg = weight / count;
            double diff = Math.Abs(avg - globalAvg);
            if (diff <= m)
            {
                Console.WriteLine(
                    $"\tПодходит: {data[i].PassengerName} " +
                    $"(средняя {Math.Round(avg, 2)} кг)");
                found = true;
            }
        }
        if (!found)
        {
            Console.WriteLine("\tПодходящего багажа нет");
        }
    }




    public static bool FillTextFileAuto(
        string path, int count, int min, int max)
    {
        Random rnd = new Random();
        try
        {
            using (StreamWriter writer =
                new StreamWriter(path))
            {
                for (int i = 0; i < count; i++)
                {
                    writer.WriteLine(rnd.Next(min, max + 1));
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка создания: {ex.Message}");
            return false;
        }
    }

    public static bool FillTextFileManual(
        string path, int count)
    {
        try
        {
            using (StreamWriter writer =
                new StreamWriter(path))
            {
                for (int i = 0; i < count; i++)
                {
                    Console.Write($"\tЧисло {i + 1}: ");
                    writer.WriteLine(InputValidator.ReadInt());
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка создания: {ex.Message}");
            return false;
        }
    }

    public static int[] ReadTextFileNumbers(
        string path)
    {
        if (!File.Exists(path))
        {
            return new int[0];
        }
        string[] lines = File.ReadAllLines(path);
        int[] result = new int[lines.Length];
        for (int i = 0; i < lines.Length; i++)
        {
            result[i] = int.Parse(lines[i]);
        }
        return result;
    }

    public static void DiffOfHalves(string path)
    {
        try
        {
            int[] values = ReadTextFileNumbers(path);
            if (values.Length % 2 != 0)
            {
                Console.WriteLine(
                    "\tОшибка: количество элементов нечётно");
                return;
            }
            int half = values.Length / 2;
            int sumFirst = 0;
            int sumSecond = 0;
            for (int i = 0; i < half; i++)
            {
                sumFirst = sumFirst + values[i];
            }
            for (int i = half; i < values.Length; i++)
            {
                sumSecond = sumSecond + values[i];
            }
            Console.WriteLine(
                $"\tСумма первой половины: {sumFirst}");
            Console.WriteLine(
                $"\tСумма второй половины: {sumSecond}");
            Console.WriteLine(
                $"\tРазность: {sumFirst - sumSecond}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\tОшибка: {ex.Message}");
        }
    }




    public static bool FillTextFileSeveralAuto(
        string path, int lines, int perLine,
        int min, int max)
    {
        Random rnd = new Random();
        try
        {
            using (StreamWriter writer =
                new StreamWriter(path))
            {
                for (int i = 0; i < lines; i++)
                {
                    string line = "";
                    for (int j = 0; j < perLine; j++)
                    {
                        if (j > 0) line = line + " ";
                        line = line + rnd.Next(min, max + 1);
                    }
                    writer.WriteLine(line);
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка создания: {ex.Message}");
            return false;
        }
    }

    public static bool FillTextFileSeveralManual(
        string path, int lines, int perLine)
    {
        try
        {
            using (StreamWriter writer =
                new StreamWriter(path))
            {
                for (int i = 0; i < lines; i++)
                {
                    string line = "";
                    for (int j = 0; j < perLine; j++)
                    {
                        Console.Write(
                            $"\tСтрока {i + 1}, число {j + 1}: ");
                        if (j > 0) line = line + " ";
                        line = line + InputValidator.ReadInt();
                    }
                    writer.WriteLine(line);
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка создания: {ex.Message}");
            return false;
        }
    }

  
    public static int SumElements(string path)
    {
        int sum = 0;
        char[] separators = { ' ', '\t' };
        try
        {
            using (StreamReader reader =
                new StreamReader(path))
            {
                string line = reader.ReadLine();
                while (line != null)
                {
                    string[] parts = line.Split(
                        separators,
                        StringSplitOptions.RemoveEmptyEntries);
                    for (int i = 0; i < parts.Length; i++)
                    {
                        sum = sum + int.Parse(parts[i]);
                    }
                    line = reader.ReadLine();
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\tОшибка: {ex.Message}");
        }
        return sum;
    }

    public static void PrintTextFile(string path)
    {
        if (!File.Exists(path))
        {
            Console.WriteLine("\tФайл не существует");
            return;
        }
        string[] lines = File.ReadAllLines(path);
        for (int i = 0; i < lines.Length; i++)
        {
            Console.WriteLine($"\t{lines[i]}");
        }
    }




    public static bool FillTextFileByLines(
        string path, int count)
    {
        try
        {
            using (StreamWriter writer =
                new StreamWriter(path))
            {
                for (int i = 0; i < count; i++)
                {
                    Console.Write($"\tСтрока {i + 1}: ");
                    writer.WriteLine(
                        InputValidator.ReadNonEmptyString());
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка создания: {ex.Message}");
            return false;
        }
    }

    public static bool FillTextFileByWords(
        string path, int count)
    {
        string[] words = { "моноколесо", "синица", "Игнатий",
            "субкультура", "расположиться", "курение", "любвиобильность",
            "гражданин Апполионарий" };
        Random rnd = new Random();
        try
        {
            using (StreamWriter writer =
                new StreamWriter(path))
            {
                for (int i = 0; i < count; i++)
                {
                    int wordsCount = rnd.Next(2, 7);
                    string line = "";
                    for (int j = 0; j < wordsCount; j++)
                    {
                        if (j > 0) line = line + " ";
                        line = line +
                            words[rnd.Next(words.Length)];
                    }
                    writer.WriteLine(line);
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"\tОшибка создания: {ex.Message}");
            return false;
        }
    }

    public static void CopyShortestAndLongest(
        string inputPath, string outputPath)
    {
        try
        {
            string[] lines = File.ReadAllLines(inputPath);
            if (lines.Length == 0)
            {
                Console.WriteLine("\tФайл пуст");
                return;
            }
            int minIndex = 0;
            int maxIndex = 0;
            for (int i = 1; i < lines.Length; i++)
            {
                if (lines[i].Length < lines[minIndex].Length)
                {
                    minIndex = i;
                }
                if (lines[i].Length > lines[maxIndex].Length)
                {
                    maxIndex = i;
                }
            }
            using (StreamWriter writer =
                new StreamWriter(outputPath))
            {
                writer.WriteLine(lines[minIndex]);
                if (maxIndex != minIndex)
                {
                    writer.WriteLine(lines[maxIndex]);
                }
            }
            Console.WriteLine("\n\tСамая короткая " +
                $"({lines[minIndex].Length} симв.):");
            Console.WriteLine($"\t{lines[minIndex]}");
            Console.WriteLine("\tСамая длинная " +
                $"({lines[maxIndex].Length} симв.):");
            Console.WriteLine($"\t{lines[maxIndex]}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\tОшибка: {ex.Message}");
        }
    }
}