﻿using System;

public class Matrix
{
    private int[,] _data;

    public Matrix()
    {
        _data = new int[0, 0];
    }

    public Matrix(int[,] data)
    {
        CopyFrom(data);
    }

    public Matrix(Matrix other)
    {
        if (other == null)
        {
            CopyFrom(null);
        }
        else
        {
            CopyFrom(other._data);
        }
    }

    public Matrix(int rows, int cols)
    {
        _data = new int[rows, cols];
        for (int i = 0; i < rows; i++)
        {
            for (int j = cols - 1; j >= 0; j--)
            {
                Console.Write($"\tЭлемент [{i};{j}]: ");
                _data[i, j] = InputValidator.ReadInt();
            }
        }
    }

    public Matrix(int size, int minBelow, int maxBelow,
        int minAbove, int maxAbove)
    {
        _data = new int[size, size];
        Random random = new Random();
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (i > j)
                {
                    _data[i, j] = random.Next(
                        minBelow, maxBelow + 1);
                }
                else
                {
                    _data[i, j] = random.Next(
                        minAbove, maxAbove + 1);
                }
            }
        }
    }

    public Matrix(int size)
    {
        _data = new int[size, size];
        int counter = 1;
        for (int d = size - 1; d >= 0; d--)
        {
            for (int i = d; i < size; i++)
            {
                _data[i, i - d] = counter;
                counter++;
            }
        }
    }

    public int[,] Data
    {
        get { return _data; }
        set { CopyFrom(value); }
    }

    public int RowCount
    {
        get { return _data.GetLength(0); }
    }

    public int ColCount
    {
        get { return _data.GetLength(1); }
    }
    public void FillManual(int rows, int cols)
    {
        _data = new int[rows, cols];
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                Console.Write($"\tЭлемент [{i};{j}]: ");
                _data[i, j] = InputValidator.ReadInt();
            }
        }
    }

    public void FillRandom(int rows, int cols,
    int min, int max)
    {
        _data = new int[rows, cols];
        Random random = new Random();
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                _data[i, j] = random.Next(min, max + 1);
            }
        }
    }
    public int? MaxUnique()
    {
        int rows = _data.GetLength(0);
        int cols = _data.GetLength(1);
        int? max = null;
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                int current = _data[i, j];
                if (CountOccurrences(current) == 1)
                {
                    if (max == null || current > max.Value)
                    {
                        max = current;
                    }
                }
            }
        }
        return max;
    }

    private int CountOccurrences(int value)
    {
        int count = 0;
        int rows = _data.GetLength(0);
        int cols = _data.GetLength(1);
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if (_data[i, j] == value)
                {
                    count++;
                }
            }
        }
        return count;
    }

    private void CopyFrom(int[,] source)
    {
        if (source == null)
        {
            _data = new int[0, 0];
            return;
        }
        int rows = source.GetLength(0);
        int cols = source.GetLength(1);
        _data = new int[rows, cols];
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                _data[i, j] = source[i, j];
            }
        }
    }
    public static Matrix operator -(Matrix left,
    Matrix right)
    {
        if (left.RowCount != right.RowCount ||
            left.ColCount != right.ColCount)
        {
            throw new ArgumentException(
                "\tРазмерности матриц для " +
                "вычитания должны совпадать");
        }
        int rows = left._data.GetLength(0);
        int cols = left._data.GetLength(1);
        int[,] result = new int[rows, cols];
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                result[i, j] =
                    left._data[i, j] - right._data[i, j];
            }
        }
        return new Matrix(result);
    }

    public static Matrix operator *(Matrix left,
    Matrix right)
    {
        if (left.ColCount != right.RowCount)
        {
            throw new ArgumentException(
                "\tКоличество столбцов первой " +
                "матрицы должно совпадать с " +
                "количеством строк второй");
        }
        int rows = left._data.GetLength(0);
        int inner = left._data.GetLength(1);
        int cols = right._data.GetLength(1);
        int[,] result = new int[rows, cols];
        int sum = 0;
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                sum = 0;
                for (int p = 0; p < inner; p++)
                {
                    sum = sum +
                        left._data[i, p] * right._data[p, j];
                }
                result[i, j] = sum;
            }
        }
        return new Matrix(result);
    }

    public static Matrix operator *(int scalar,
        Matrix matrix)
    {
        int rows = matrix._data.GetLength(0);
        int cols = matrix._data.GetLength(1);
        int[,] result = new int[rows, cols];
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                result[i, j] =
                    matrix._data[i, j] * scalar;
            }
        }
        return new Matrix(result);
    }

    public override string ToString()
    {
        string result = "";
        int rows = _data.GetLength(0);
        int cols = _data.GetLength(1);
        for (int i = 0; i < rows; i++)
        {
            result = result + "\t";
            for (int j = 0; j < cols; j++)
            {
                result = result + _data[i, j].ToString().PadLeft(6);
            }
            result = result + "\n";
        }
        return result.TrimEnd('\r', '\n');
    }
}